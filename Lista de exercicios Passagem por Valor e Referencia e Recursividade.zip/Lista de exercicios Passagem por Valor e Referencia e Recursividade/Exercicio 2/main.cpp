#include "iostream"
#include "ctime"
#include "iomanip"
using namespace std;

void converteTempo(int totalMinutos, int &horaAtual, int &minutoAtual){
    horaAtual = totalMinutos / 60;
    minutoAtual = totalMinutos % 60;
}

int main(){
    int totalMinutos = 0, horaAtual = 0, minutoAtual = 0;

    cout << "Informe o total de minutos que se passaram desde meia-noite: " << endl;
    cin >> totalMinutos;

    converteTempo(totalMinutos, horaAtual, minutoAtual);
    cout << setw(2) << setfill('0') << horaAtual  << ":" << setw(2) << setfill('0') <<  minutoAtual << " Horas" <<endl;
    return 0;
}