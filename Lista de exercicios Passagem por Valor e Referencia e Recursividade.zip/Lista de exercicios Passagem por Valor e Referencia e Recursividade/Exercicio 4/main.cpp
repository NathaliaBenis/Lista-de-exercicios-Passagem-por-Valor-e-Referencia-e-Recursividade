#include <iostream>
using namespace std;

void lerMatriz(int** matriz, int M, int N) {
    cout << "Informe os elementos da matriz (" << M << "x" << N << "):" << endl;
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cin >> matriz[i][j];
        }
    }
}

void calcularTransposta(int** matriz, int** transposta, int M, int N) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            transposta[j][i] = matriz[i][j];
        }
    }
}

void multiplicarPorFator(int** matriz, int M, int N, int K) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            matriz[i][j] *= K;
        }
    }
}

void adicionarMatrizes(int** matriz1, int** matriz2, int** resultado, int M, int N) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            resultado[i][j] = matriz1[i][j] + matriz2[i][j];
        }
    }
}

void imprimirMatriz(int** matriz, int M, int N) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int M, N, K;

    cout << "Informe o numero de linhas (M <= 20): ";
    cin >> M;
    cout << "Informe o numero de colunas (N <= 25): ";
    cin >> N;

    int** matriz1 = new int*[M];
    int** matriz2 = new int*[M];
    int** transposta = new int*[N];
    int** resultado = new int*[M];

    for (int i = 0; i < M; i++) {
        matriz1[i] = new int[N];
        matriz2[i] = new int[N];
        resultado[i] = new int[N];
    }

    for (int i = 0; i < N; i++) {
        transposta[i] = new int[M];
    }

    lerMatriz(matriz1, M, N);

    calcularTransposta(matriz1, transposta, M, N);
    cout << "Matriz Transposta:" << endl;
    imprimirMatriz(transposta, N, M);

    cout << "Informe o fator K para multiplicacao: ";
    cin >> K;
    multiplicarPorFator(matriz1, M, N, K);
    cout << "Matriz apos multiplicacao por " << K << ":" << endl;
    imprimirMatriz(matriz1, M, N);

    cout << "Informe os elementos da segunda matriz para adicao: " << endl;
    lerMatriz(matriz2, M, N);

    adicionarMatrizes(matriz1, matriz2, resultado, M, N);
    cout << "O resultado da soma das matrizes e: " << endl;
    imprimirMatriz(resultado, M, N);

    for (int i = 0; i < M; i++) {
        delete[] matriz1[i];
        delete[] matriz2[i];
        delete[] resultado[i];
    }

    for (int i = 0; i < N; i++) {
        delete[] transposta[i];
    }

    delete[] matriz1;
    delete[] matriz2;
    delete[] transposta;
    delete[] resultado;

    return 0;
}